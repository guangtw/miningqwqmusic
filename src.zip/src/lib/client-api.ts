"use client";

import type {
  AlbumDetail,
  ApiFailure,
  ApiResult,
  ArtistSearchItem,
  ArtistDetail,
  DiscoverData,
  DownloadSource,
  PagedResult,
  Playlist,
  PlaylistResolveResult,
  PlaySource,
  PlaySourceRequestOptions,
  SceneData,
  SearchAssist,
  SongInsight,
  TrackQualityAvailability,
  ToplistItem,
  Track,
  TrackLyric
} from "@/src/types/music";

export class ClientApiError extends Error {
  readonly code: number;
  readonly status: number;
  readonly traceId?: string;
  readonly retryable: boolean;

  constructor(message: string, options: { code: number; status: number; traceId?: string; retryable?: boolean }) {
    super(message);
    this.name = "ClientApiError";
    this.code = options.code;
    this.status = options.status;
    this.traceId = options.traceId;
    this.retryable = options.retryable ?? false;
  }
}

function isApiFailure(payload: unknown): payload is ApiFailure {
  if (!payload || typeof payload !== "object") return false;
  return "code" in payload && "message" in payload && "traceId" in payload && "retryable" in payload;
}

async function readResult<T>(response: Response): Promise<T> {
  let payload: ApiResult<T> | null = null;
  try {
    payload = (await response.json()) as ApiResult<T>;
  } catch {
    throw new ClientApiError(`请求失败（HTTP ${response.status}）`, {
      code: 5000,
      status: response.status,
      retryable: false
    });
  }

  if (!response.ok) {
    if (isApiFailure(payload)) {
      throw new ClientApiError(payload.message || `请求失败（HTTP ${response.status}）`, {
        code: payload.code,
        status: response.status,
        traceId: payload.traceId,
        retryable: payload.retryable
      });
    }
    throw new ClientApiError(`请求失败（HTTP ${response.status}）`, {
      code: 5000,
      status: response.status,
      retryable: false
    });
  }

  if ("data" in payload) {
    return payload.data;
  }
  throw new ClientApiError(isApiFailure(payload) ? payload.message || "接口返回异常" : "接口返回异常", {
    code: isApiFailure(payload) ? payload.code : 5000,
    status: response.status || 500,
    traceId: isApiFailure(payload) ? payload.traceId : undefined,
    retryable: isApiFailure(payload) ? payload.retryable : false
  });
}

export async function searchMusic(keyword: string, page = 1, pageSize = 20): Promise<PagedResult<Track>> {
  const response = await fetch(`/api/music/search?q=${encodeURIComponent(keyword)}&page=${page}&pageSize=${pageSize}`, {
    method: "GET"
  });
  return readResult<PagedResult<Track>>(response);
}

export async function searchArtists(keyword: string, page = 1, pageSize = 20): Promise<PagedResult<ArtistSearchItem>> {
  const response = await fetch(`/api/music/search/artists?q=${encodeURIComponent(keyword)}&page=${page}&pageSize=${pageSize}`, {
    method: "GET"
  });
  return readResult<PagedResult<ArtistSearchItem>>(response);
}

export async function searchPlaylists(keyword: string, page = 1, pageSize = 20): Promise<PagedResult<Playlist>> {
  const response = await fetch(`/api/music/search/playlists?q=${encodeURIComponent(keyword)}&page=${page}&pageSize=${pageSize}`, {
    method: "GET"
  });
  return readResult<PagedResult<Playlist>>(response);
}

export async function getTrackPlaySource(
  trackId: string,
  options?: PlaySourceRequestOptions,
  accessToken?: string | null
): Promise<PlaySource> {
  const search = new URLSearchParams();
  if (options?.level) {
    search.set("level", options.level);
  }
  if (options?.unblockMode) {
    search.set("unblockMode", options.unblockMode);
  }
  const query = search.size ? `?${search.toString()}` : "";
  const headers = new Headers();
  if (accessToken) {
    headers.set("authorization", `Bearer ${accessToken}`);
  }
  const response = await fetch(`/api/music/track/${trackId}/play-url${query}`, {
    method: "GET",
    headers,
    cache: "no-store"
  });
  return readResult<PlaySource>(response);
}

export async function getTrackLyric(trackId: string): Promise<TrackLyric> {
  const response = await fetch(`/api/music/track/${trackId}/lyric`, {
    method: "GET"
  });
  return readResult<TrackLyric>(response);
}

export async function getTrackDetail(trackId: string): Promise<Track> {
  const response = await fetch(`/api/music/track/${trackId}`, {
    method: "GET"
  });
  return readResult<Track>(response);
}

export async function getTrackQualityAvailability(trackId: string, accessToken?: string | null): Promise<TrackQualityAvailability> {
  const headers = new Headers();
  if (accessToken) {
    headers.set("authorization", `Bearer ${accessToken}`);
  }
  const response = await fetch(`/api/music/track/${trackId}/quality-options`, {
    method: "GET",
    headers,
    cache: "no-store"
  });
  return readResult<TrackQualityAvailability>(response);
}

export async function getPlaylistDetail(playlistId: string): Promise<Playlist> {
  const response = await fetch(`/api/music/playlist/${playlistId}`, {
    method: "GET"
  });
  return readResult<Playlist>(response);
}

export async function resolvePlaylistInput(input: string): Promise<PlaylistResolveResult> {
  const response = await fetch(`/api/music/playlist/resolve?input=${encodeURIComponent(input)}`, {
    method: "GET"
  });
  return readResult<PlaylistResolveResult>(response);
}

export async function getDiscoverHome(): Promise<DiscoverData> {
  const response = await fetch("/api/music/discover/home", {
    method: "GET"
  });
  return readResult<DiscoverData>(response);
}

export async function getSearchAssist(keyword = ""): Promise<SearchAssist> {
  const response = await fetch(`/api/music/discover/search-assist?q=${encodeURIComponent(keyword)}`, {
    method: "GET"
  });
  return readResult<SearchAssist>(response);
}

export async function getToplist(): Promise<ToplistItem[]> {
  const response = await fetch("/api/music/toplist", {
    method: "GET"
  });
  return readResult<ToplistItem[]>(response);
}

export async function getToplistDetail(toplistId: string): Promise<Playlist> {
  const response = await fetch(`/api/music/toplist/${toplistId}`, {
    method: "GET"
  });
  return readResult<Playlist>(response);
}

export async function getAlbumDetail(albumId: string): Promise<AlbumDetail> {
  const response = await fetch(`/api/music/album/${albumId}`, {
    method: "GET"
  });
  return readResult<AlbumDetail>(response);
}

export async function getArtistDetail(artistId: string): Promise<ArtistDetail> {
  const response = await fetch(`/api/music/artist/${artistId}`, {
    method: "GET"
  });
  return readResult<ArtistDetail>(response);
}

export async function getTrackInsight(trackId: string): Promise<SongInsight> {
  const response = await fetch(`/api/music/track/${trackId}/insight`, {
    method: "GET"
  });
  return readResult<SongInsight>(response);
}

export async function getTrackDownloadUrl(trackId: string, level?: string): Promise<DownloadSource> {
  const query = level ? `?level=${encodeURIComponent(level)}` : "";
  const response = await fetch(`/api/music/track/${trackId}/download-url${query}`, {
    method: "GET"
  });
  return readResult<DownloadSource>(response);
}

export async function getSatiScene(tag?: string): Promise<SceneData> {
  const query = tag ? `?tag=${encodeURIComponent(tag)}` : "";
  const response = await fetch(`/api/music/scene/sati${query}`, {
    method: "GET"
  });
  return readResult<SceneData>(response);
}

export async function getSportScene(bpm = 130): Promise<SceneData> {
  const response = await fetch(`/api/music/scene/sport?bpm=${Math.round(bpm)}`, {
    method: "GET"
  });
  return readResult<SceneData>(response);
}
