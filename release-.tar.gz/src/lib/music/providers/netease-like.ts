import { AppError } from "@/src/lib/errors";
import { fetchWithRetry } from "@/src/lib/http";
import { parseLyric } from "@/src/lib/lyrics";
import type { MusicSourceAdapter, TrackSearchInput } from "@/src/lib/music/adapter";
import type {
  AlbumDetail,
  ArtistDetail,
  DiscoverBlock,
  DiscoverData,
  DownloadSource,
  PagedResult,
  Playlist,
  PlaySource,
  SceneData,
  SceneResource,
  SearchAssist,
  SongCreator,
  SongInsight,
  ToplistItem,
  Track,
  TrackLyric
} from "@/src/types/music";

type NeteaseArtist = {
  id: number | string;
  name: string;
  img1v1Url?: string;
  picUrl?: string;
};

type NeteaseAlbum = {
  id: number | string;
  name: string;
  picUrl?: string;
  pic?: string;
  coverImgUrl?: string;
  blurPicUrl?: string;
};

type NeteaseSong = {
  id: number | string;
  name: string;
  ar?: NeteaseArtist[];
  artists?: NeteaseArtist[];
  al?: NeteaseAlbum;
  album?: NeteaseAlbum;
  picUrl?: string;
  coverImgUrl?: string;
  dt?: number;
  duration?: number;
};

type AdapterConfig = {
  baseUrl: string;
  apiKey?: string;
  timeoutMs: number;
  retries: number;
  playLevel: string;
  downloadLevel: string;
  vipPreviewMaxMs: number;
  lyricPreferNew: boolean;
  enableDiscover: boolean;
  enableScene: boolean;
  pathPlayUrlUnblock?: string;
  unblockSource?: string;
  unblockSources?: string[];
  pathSearch: string;
  pathTrackDetail: string;
  pathPlayUrl: string;
  pathLyric: string;
  pathLyricNew: string;
  pathPlaylist: string;
  pathSearchHotDetail: string;
  pathSearchDefault: string;
  pathSearchSuggestPc: string;
  pathBanner: string;
  pathPersonalized: string;
  pathToplistDetail: string;
  pathTopPlaylistHighquality: string;
  pathToplist: string;
  pathAlbum: string;
  pathAlbumDetail: string;
  pathArtistDetail: string;
  pathArtistTopSong: string;
  pathCheckMusic: string;
  pathSongCreators: string;
  pathSongWikiSummary: string;
  pathSongChorus: string;
  pathSongCopyrightRcmd: string;
  pathSongDownloadUrl: string;
  pathSatiTagList: string;
  pathSatiResourceList: string;
  pathRadioSportGet: string;
};

type PlayData = {
  id?: number;
  url?: string | null;
  br?: number;
  size?: number;
  code?: number;
  time?: number;
  expi?: number;
  expiresAt?: string;
  level?: string | null;
  type?: string | null;
};

type AnyRecord = Record<string, unknown>;

function asObject(value: unknown): AnyRecord {
  return value && typeof value === "object" ? (value as AnyRecord) : {};
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function asString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value : undefined;
}

function asNumber(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function parseCsvList(value: string | undefined): string[] {
  if (!value) return [];
  return value
    .split(",")
    .map((item) => item.trim())
    .filter((item) => Boolean(item));
}

function normalizePath(path: string): string {
  return path.startsWith("/") ? path : `/${path}`;
}

function trimEndSlash(url: string): string {
  return url.endsWith("/") ? url.slice(0, -1) : url;
}

function resolveCoverUrl(song: NeteaseSong, albumRaw?: NeteaseAlbum): string | undefined {
  return (
    albumRaw?.picUrl ??
    albumRaw?.pic ??
    albumRaw?.coverImgUrl ??
    albumRaw?.blurPicUrl ??
    song.picUrl ??
    song.coverImgUrl
  );
}

function toTrack(song: NeteaseSong): Track {
  const artists = (song.ar ?? song.artists ?? []).map((artist) => ({
    id: String(artist.id),
    name: artist.name,
    coverUrl: artist.img1v1Url ?? artist.picUrl
  }));
  const albumRaw = song.al ?? song.album;
  const coverUrl = resolveCoverUrl(song, albumRaw);
  const album = albumRaw
    ? {
        id: String(albumRaw.id),
        name: albumRaw.name,
        coverUrl
      }
    : undefined;
  return {
    id: String(song.id),
    name: song.name,
    artists,
    album,
    durationMs: song.dt ?? song.duration ?? 0,
    coverUrl
  };
}

function toTrackFromLoose(rawSong: unknown): Track {
  const song = asObject(rawSong);
  const artistsLoose = asArray<AnyRecord>(song.ar ?? song.artists);
  const artists = artistsLoose.map((artist) => ({
    id: String(artist.id ?? ""),
    name: String(artist.name ?? "未知歌手"),
    coverUrl: asString(artist.img1v1Url) ?? asString(artist.picUrl)
  }));

  const albumLoose = asObject(song.al ?? song.album);
  const coverUrl =
    asString(albumLoose.picUrl) ??
    asString(albumLoose.pic) ??
    asString(albumLoose.coverImgUrl) ??
    asString(albumLoose.blurPicUrl) ??
    asString(song.picUrl) ??
    asString(song.coverImgUrl);

  return {
    id: String(song.id ?? ""),
    name: String(song.name ?? "未知歌曲"),
    artists,
    album:
      albumLoose.id || albumLoose.name
        ? {
            id: String(albumLoose.id ?? ""),
            name: String(albumLoose.name ?? "未知专辑"),
            coverUrl
          }
        : undefined,
    durationMs: asNumber(song.dt) ?? asNumber(song.duration) ?? 0,
    coverUrl
  };
}

export class NeteaseLikeAdapter implements MusicSourceAdapter {
  private readonly config: AdapterConfig;

  constructor(config: Partial<AdapterConfig> & Pick<AdapterConfig, "baseUrl" | "timeoutMs" | "retries">) {
    this.config = {
      baseUrl: trimEndSlash(config.baseUrl),
      apiKey: config.apiKey,
      timeoutMs: config.timeoutMs,
      retries: config.retries,
      playLevel: config.playLevel ?? "standard",
      downloadLevel: config.downloadLevel ?? "exhigh",
      vipPreviewMaxMs: config.vipPreviewMaxMs ?? 60000,
      lyricPreferNew: config.lyricPreferNew ?? true,
      enableDiscover: config.enableDiscover ?? true,
      enableScene: config.enableScene ?? true,
      pathPlayUrlUnblock: config.pathPlayUrlUnblock,
      unblockSource: config.unblockSource,
      unblockSources: config.unblockSources ?? [],
      pathSearch: config.pathSearch ?? "/search",
      pathTrackDetail: config.pathTrackDetail ?? "/song/detail",
      pathPlayUrl: config.pathPlayUrl ?? "/song/url/v1",
      pathLyric: config.pathLyric ?? "/lyric",
      pathLyricNew: config.pathLyricNew ?? "/lyric/new",
      pathPlaylist: config.pathPlaylist ?? "/playlist/detail",
      pathSearchHotDetail: config.pathSearchHotDetail ?? "/search/hot/detail",
      pathSearchDefault: config.pathSearchDefault ?? "/search/default",
      pathSearchSuggestPc: config.pathSearchSuggestPc ?? "/search/suggest/pc",
      pathBanner: config.pathBanner ?? "/banner",
      pathPersonalized: config.pathPersonalized ?? "/personalized",
      pathToplistDetail: config.pathToplistDetail ?? "/toplist/detail",
      pathTopPlaylistHighquality: config.pathTopPlaylistHighquality ?? "/top/playlist/highquality",
      pathToplist: config.pathToplist ?? "/toplist",
      pathAlbum: config.pathAlbum ?? "/album",
      pathAlbumDetail: config.pathAlbumDetail ?? "/album/detail",
      pathArtistDetail: config.pathArtistDetail ?? "/artist/detail",
      pathArtistTopSong: config.pathArtistTopSong ?? "/artist/top/song",
      pathCheckMusic: config.pathCheckMusic ?? "/check/music",
      pathSongCreators: config.pathSongCreators ?? "/song/creators",
      pathSongWikiSummary: config.pathSongWikiSummary ?? "/song/wiki/summary",
      pathSongChorus: config.pathSongChorus ?? "/song/chorus",
      pathSongCopyrightRcmd: config.pathSongCopyrightRcmd ?? "/song/copyright/rcmd",
      pathSongDownloadUrl: config.pathSongDownloadUrl ?? "/song/download/url/v1",
      pathSatiTagList: config.pathSatiTagList ?? "/sati/tag/list",
      pathSatiResourceList: config.pathSatiResourceList ?? "/sati/resource/list",
      pathRadioSportGet: config.pathRadioSportGet ?? "/radio/sport/get"
    };
  }

  private async request<T>(path: string, query: Record<string, string | number | boolean>) {
    const url = new URL(`${this.config.baseUrl}${normalizePath(path)}`);
    Object.entries(query).forEach(([key, value]) => {
      url.searchParams.set(key, String(value));
    });
    return fetchWithRetry<T>(
      url.toString(),
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          ...(this.config.apiKey ? { "x-api-key": this.config.apiKey } : {})
        }
      },
      {
        timeoutMs: this.config.timeoutMs,
        retries: this.config.retries
      }
    );
  }

  private async requestSafe<T>(path: string, query: Record<string, string | number | boolean>): Promise<T | null> {
    try {
      return await this.request<T>(path, query);
    } catch {
      return null;
    }
  }

  private extractPlayData(raw: unknown): PlayData | null {
    const payload = asObject(raw);
    const pickFromCandidate = (value: unknown): PlayData | null => {
      if (Array.isArray(value)) {
        for (const item of value) {
          const entry = asObject(item) as PlayData;
          if (Object.keys(entry).length) {
            return entry;
          }
        }
        return null;
      }
      if (value && typeof value === "object") {
        return value as PlayData;
      }
      return null;
    };

    const topData = pickFromCandidate(payload.data);
    if (topData) return topData;

    const nestedResultData = pickFromCandidate(asObject(payload.result).data);
    if (nestedResultData) return nestedResultData;

    if (typeof payload.url === "string") {
      return {
        url: payload.url,
        br: asNumber(payload.br),
        time: asNumber(payload.time),
        expi: asNumber(payload.expi)
      };
    }
    return null;
  }

  private isVipPreview(data: PlayData): boolean {
    return Boolean(data.time && data.time > 0 && data.time <= this.config.vipPreviewMaxMs);
  }

  private toPlaySource(trackId: string, data: PlayData): PlaySource {
    return {
      trackId,
      url: data.url ?? "",
      bitrate: data.br,
      ttlSeconds: data.time
        ? Math.max(10, Math.floor(data.time / 1000))
        : data.expi
          ? Math.max(10, Math.floor(data.expi))
          : undefined,
      expiresAt: data.expiresAt
    };
  }

  async searchTracks(input: TrackSearchInput): Promise<PagedResult<Track>> {
    const offset = (input.page - 1) * input.pageSize;
    const raw = await this.request<{ result?: { songs?: NeteaseSong[]; songCount?: number } }>(
      this.config.pathSearch,
      {
        keywords: input.keyword,
        limit: input.pageSize,
        offset
      }
    );

    const songs = raw.result?.songs ?? [];
    return {
      items: songs.map(toTrack),
      page: input.page,
      pageSize: input.pageSize,
      total: raw.result?.songCount ?? songs.length
    };
  }

  async getTrackDetail(trackId: string): Promise<Track> {
    const raw = await this.request<{ songs?: NeteaseSong[] }>(this.config.pathTrackDetail, { ids: trackId });
    const song = raw.songs?.[0];
    if (!song) {
      throw new AppError("Track not found", { code: 3001, status: 404, retryable: false });
    }
    return toTrack(song);
  }

  async getPlaySource(trackId: string): Promise<PlaySource> {
    const raw = await this.request<{ data?: unknown; url?: string }>(this.config.pathPlayUrl, {
      id: trackId,
      level: this.config.playLevel
    });
    const data = this.extractPlayData(raw);
    if (!data?.url) {
      throw new AppError("Play source unavailable", { code: 3002, status: 404, retryable: true });
    }

    const isVipPreview = this.isVipPreview(data);
    if (!isVipPreview || !this.config.pathPlayUrlUnblock) {
      return this.toPlaySource(trackId, data);
    }

    const sourceCandidates = this.config.unblockSources?.length
      ? this.config.unblockSources
      : this.config.unblockSource
        ? [this.config.unblockSource]
        : [""];

    for (const source of sourceCandidates) {
      try {
        const unblockRaw = await this.requestSafe<{ data?: unknown; url?: string }>(this.config.pathPlayUrlUnblock, {
          id: trackId,
          level: this.config.playLevel,
          ...(source ? { source } : {})
        });
        if (!unblockRaw) continue;
        const unblockData = this.extractPlayData(unblockRaw);
        if (!unblockData?.url) continue;
        if (!this.isVipPreview(unblockData)) {
          return this.toPlaySource(trackId, unblockData);
        }
      } catch {
        // 当前解灰 source 不可用时自动尝试下一个 source。
      }
    }

    return this.toPlaySource(trackId, data);
  }

  async getTrackLyric(trackId: string): Promise<TrackLyric> {
    const primaryPath = this.config.lyricPreferNew ? this.config.pathLyricNew : this.config.pathLyric;
    const fallbackPath = this.config.lyricPreferNew ? this.config.pathLyric : this.config.pathLyricNew;
    let raw = await this.requestSafe<AnyRecord>(primaryPath, { id: trackId });
    if (!raw) {
      raw = await this.requestSafe<AnyRecord>(fallbackPath, { id: trackId });
    }

    const lrc = asObject(raw?.lrc);
    const tlyric = asObject(raw?.tlyric);
    const klyric = asObject(raw?.romalrc);
    const base = asString(lrc.lyric) ?? "";
    const translated = asString(tlyric.lyric) ?? "";
    const karaoke = asString(klyric.lyric) ?? "";

    return {
      trackId,
      raw: base,
      lines: parseLyric(base),
      translatedRaw: translated || undefined,
      translatedLines: translated ? parseLyric(translated) : undefined,
      karaokeRaw: karaoke || undefined,
      karaokeLines: karaoke ? parseLyric(karaoke) : undefined
    };
  }

  async getPlaylist(playlistId: string): Promise<Playlist> {
    const raw = await this.request<{ playlist?: AnyRecord }>(this.config.pathPlaylist, { id: playlistId });
    const playlist = raw.playlist;
    if (!playlist) {
      throw new AppError("Playlist not found", { code: 3003, status: 404, retryable: false });
    }

    const tracks = asArray<NeteaseSong>(playlist.tracks).map(toTrack);
    return {
      id: String(playlist.id ?? playlistId),
      name: String(playlist.name ?? "未知歌单"),
      description: asString(playlist.description),
      coverUrl: asString(playlist.coverImgUrl),
      tracks
    };
  }

  async getSearchAssist(keyword: string): Promise<SearchAssist> {
    const [defaultRaw, hotRaw, suggestRaw] = await Promise.all([
      this.requestSafe<AnyRecord>(this.config.pathSearchDefault, {}),
      this.requestSafe<AnyRecord>(this.config.pathSearchHotDetail, {}),
      keyword.trim()
        ? this.requestSafe<AnyRecord>(this.config.pathSearchSuggestPc, { keyword: keyword.trim() })
        : Promise.resolve(null)
    ]);

    const defaultKeyword =
      asString(asObject(defaultRaw?.data).realkeyword) ??
      asString(asObject(defaultRaw?.data).showKeyword) ??
      asString(asObject(asObject(defaultRaw?.data).styleKeyword).keyWord);

    const hotKeywords = asArray<AnyRecord>(hotRaw?.data)
      .map((item) => asString(item.searchWord))
      .filter((item): item is string => Boolean(item))
      .slice(0, 12);

    const suggestKeywords = (() => {
      const suggestData = asObject(suggestRaw?.data);
      const fromSuggests = asArray<AnyRecord>(suggestData.suggests)
        .map((item) => asString(item.keyword) ?? asString(item.text))
        .filter((item): item is string => Boolean(item));
      const fromRecs = asArray<AnyRecord>(suggestData.recs)
        .map((item) => asString(item.keyword) ?? asString(item.text))
        .filter((item): item is string => Boolean(item));
      const merged = [...fromSuggests, ...fromRecs];
      return Array.from(new Set(merged)).slice(0, 10);
    })();

    return {
      defaultKeyword,
      hotKeywords,
      suggestions: suggestKeywords
    };
  }

  async getDiscoverData(): Promise<DiscoverData> {
    if (!this.config.enableDiscover) {
      return { blocks: [], searchAssist: { defaultKeyword: undefined, hotKeywords: [], suggestions: [] } };
    }

    const [assist, bannerRaw, personalizedRaw, toplistRaw, highQualityRaw] = await Promise.all([
      this.getSearchAssist(""),
      this.requestSafe<AnyRecord>(this.config.pathBanner, {}),
      this.requestSafe<AnyRecord>(this.config.pathPersonalized, { limit: 8 }),
      this.requestSafe<AnyRecord>(this.config.pathToplistDetail, {}),
      this.requestSafe<AnyRecord>(this.config.pathTopPlaylistHighquality, { limit: 8 })
    ]);

    const blocks: DiscoverBlock[] = [];

    const banners = asArray<AnyRecord>(bannerRaw?.banners)
      .map((item, index) => ({
        id: String(item.targetId ?? item.encodeId ?? `banner-${index}`),
        title: asString(item.typeTitle) ?? "推荐内容",
        subtitle: asString(item.copywriter) ?? asString(item.typeTitle) ?? "精选内容推荐",
        coverUrl: asString(item.imageUrl) ?? asString(item.pic),
        type: "banner" as const,
        targetId: asString(item.targetId)
      }))
      .slice(0, 8);
    if (banners.length) {
      blocks.push({ id: "discover-banner", title: "推荐内容", items: banners });
    }

    const personalized = asArray<AnyRecord>(personalizedRaw?.result)
      .map((item) => ({
        id: String(item.id ?? ""),
        title: asString(item.name) ?? "推荐歌单",
        subtitle: asString(item.copywriter),
        coverUrl: asString(item.picUrl),
        type: "playlist" as const,
        targetId: String(item.id ?? "")
      }))
      .slice(0, 12);
    if (personalized.length) {
      blocks.push({ id: "discover-personalized", title: "推荐歌单", items: personalized });
    }

    const topListEntries = asArray<AnyRecord>(toplistRaw?.list)
      .map((item) => ({
        id: String(item.id ?? ""),
        title: asString(item.name) ?? "榜单",
        subtitle: asString(item.updateFrequency) ?? asString(item.description),
        coverUrl: asString(item.coverImgUrl),
        type: "toplist" as const,
        targetId: String(item.id ?? "")
      }))
      .slice(0, 10);
    if (topListEntries.length) {
      blocks.push({ id: "discover-toplist", title: "热门榜单", items: topListEntries });
    }

    const highQualityEntries = asArray<AnyRecord>(highQualityRaw?.playlists)
      .map((item) => ({
        id: String(item.id ?? ""),
        title: asString(item.name) ?? "精品歌单",
        subtitle: asString(item.description),
        coverUrl: asString(item.coverImgUrl),
        type: "playlist" as const,
        targetId: String(item.id ?? "")
      }))
      .slice(0, 12);
    if (highQualityEntries.length) {
      blocks.push({ id: "discover-highquality", title: "精品歌单", items: highQualityEntries });
    }

    return {
      blocks,
      searchAssist: assist
    };
  }

  async getToplist(): Promise<ToplistItem[]> {
    const raw = await this.request<AnyRecord>(this.config.pathToplist, {});
    const items = asArray<AnyRecord>(raw.list);
    return items.map((item) => {
      const previewTracks = asArray<AnyRecord>(item.tracks).slice(0, 3).map((track, index) => ({
        id: String(track.id ?? `${item.id}-preview-${index}`),
        name: asString(track.first) ?? asString(track.name) ?? "未知歌曲",
        artists: [
          {
            id: "",
            name: asString(track.second) ?? "未知歌手"
          }
        ],
        durationMs: asNumber(track.dt) ?? 0
      }));
      return {
        id: String(item.id ?? ""),
        name: asString(item.name) ?? "未知榜单",
        description: asString(item.description),
        coverUrl: asString(item.coverImgUrl),
        updateFrequency: asString(item.updateFrequency),
        tracksPreview: previewTracks
      };
    });
  }

  async getAlbumDetail(albumId: string): Promise<AlbumDetail> {
    const raw = await this.request<AnyRecord>(this.config.pathAlbum, { id: albumId });
    const albumRaw = asObject(raw.album);
    const songs = asArray<NeteaseSong>(raw.songs);
    const artists = asArray<NeteaseArtist>(albumRaw.artists).map((artist) => ({
      id: String(artist.id),
      name: artist.name,
      coverUrl: artist.img1v1Url ?? artist.picUrl
    }));

    return {
      id: String(albumRaw.id ?? albumId),
      name: String(albumRaw.name ?? "未知专辑"),
      description: asString(albumRaw.description),
      coverUrl: asString(albumRaw.picUrl) ?? asString(albumRaw.blurPicUrl),
      publishTime: asNumber(albumRaw.publishTime),
      artists,
      tracks: songs.map(toTrack)
    };
  }

  async getArtistDetail(artistId: string): Promise<ArtistDetail> {
    const [detailRaw, topSongRaw] = await Promise.all([
      this.requestSafe<AnyRecord>(this.config.pathArtistDetail, { id: artistId }),
      this.requestSafe<AnyRecord>(this.config.pathArtistTopSong, { id: artistId })
    ]);

    const artistRoot = asObject(detailRaw?.data);
    const artist = asObject(artistRoot.artist);
    const topSongs = asArray<NeteaseSong>(topSongRaw?.songs);

    return {
      id: String(artist.id ?? artistId),
      name: asString(artist.name) ?? "未知歌手",
      coverUrl: asString(artist.cover) ?? asString(artist.avatar) ?? asString(artist.picUrl),
      briefDesc: asString(artist.briefDesc),
      topTracks: topSongs.map(toTrack)
    };
  }

  async getTrackInsight(trackId: string): Promise<SongInsight> {
    const [playableRaw, creatorsRaw, wikiRaw, chorusRaw, alternativesRaw] = await Promise.all([
      this.requestSafe<AnyRecord>(this.config.pathCheckMusic, { id: trackId }),
      this.requestSafe<AnyRecord>(this.config.pathSongCreators, { id: trackId }),
      this.requestSafe<AnyRecord>(this.config.pathSongWikiSummary, { id: trackId }),
      this.requestSafe<AnyRecord>(this.config.pathSongChorus, { id: trackId }),
      this.requestSafe<AnyRecord>(this.config.pathSongCopyrightRcmd, { songid: trackId })
    ]);

    const creatorRoles = asArray<AnyRecord>(asObject(creatorsRaw?.data).songCreatorsRoleVos);
    const creators: SongCreator[] = [];
    creatorRoles.forEach((roleItem) => {
      const roleName = asString(roleItem.roleName);
      asArray<AnyRecord>(roleItem.creatorMetaVOS).forEach((creator) => {
        const name = asString(creator.artistName);
        if (name) creators.push({ name, role: roleName });
      });
    });

    const chorusCandidates = asArray<AnyRecord>(chorusRaw?.chorus).concat(asArray<AnyRecord>(chorusRaw?.data));
    const chorusStartMs = asNumber(chorusCandidates[0]?.startTime);
    const wikiBlocks = asArray<AnyRecord>(asObject(wikiRaw?.data).blocks);
    const wikiSummary = wikiBlocks
      .flatMap((block) => asArray<AnyRecord>(block.creatives))
      .flatMap((creative) => asArray<AnyRecord>(creative.resources))
      .map((resource) => asString(asObject(resource.uiElement).mainTitle ? asObject(asObject(resource.uiElement).mainTitle).title : undefined))
      .find((text) => Boolean(text));

    const alternativesRoot = asObject(alternativesRaw?.data);
    const altSong = alternativesRoot.originSong ? [alternativesRoot.originSong] : [];
    const alternatives = altSong.map(toTrackFromLoose);

    return {
      trackId,
      playable: playableRaw ? Boolean(playableRaw.success) : undefined,
      creators,
      wikiSummary,
      chorusStartMs,
      alternatives
    };
  }

  async getDownloadSource(trackId: string, level?: string): Promise<DownloadSource> {
    const targetLevel = level ?? this.config.downloadLevel;
    const raw = await this.request<AnyRecord>(this.config.pathSongDownloadUrl, {
      id: trackId,
      level: targetLevel
    });
    const data = asObject(raw.data);
    const url = asString(data.url);
    if (!url) {
      throw new AppError("Download source unavailable", { code: 3011, status: 404, retryable: true });
    }

    return {
      trackId,
      level: asString(data.level) ?? targetLevel,
      url,
      bitrate: asNumber(data.br),
      size: asNumber(data.size),
      format: asString(data.type),
      ttlSeconds: asNumber(data.expi)
    };
  }

  async getSatiScene(tag?: string): Promise<SceneData> {
    if (!this.config.enableScene) {
      return { tags: [], resources: [] };
    }

    const tagRaw = await this.requestSafe<AnyRecord>(this.config.pathSatiTagList, {});
    const tags = asArray<AnyRecord>(tagRaw?.data).map((item) => ({
      id: String(item.tag ?? item.id ?? ""),
      name: asString(item.tagDesc) ?? asString(item.text) ?? asString(item.tag) ?? "未知标签"
    }));

    const selectedTag = tag ?? tags[0]?.id ?? "RCMD";
    const resourcesRaw = await this.requestSafe<AnyRecord>(this.config.pathSatiResourceList, { tag: selectedTag });
    const resources = asArray<AnyRecord>(resourcesRaw?.data).map(
      (item): SceneResource => ({
        id: String(item.id ?? item.trackId ?? ""),
        title: asString(item.name) ?? "未知声音",
        subtitle: asString(item.category),
        coverUrl: asString(item.pic),
        trackId: item.trackId ? String(item.trackId) : undefined,
        tag: asString(item.category)
      })
    );

    return { tags, resources };
  }

  async getSportScene(bpm: number): Promise<SceneData> {
    if (!this.config.enableScene) {
      return { tags: [], resources: [] };
    }

    const raw = await this.requestSafe<AnyRecord>(this.config.pathRadioSportGet, { bpm: Math.max(30, bpm) });
    const tracks = asArray<AnyRecord>(raw?.data);
    const resources = tracks.map(
      (item): SceneResource => ({
        id: String(item.id ?? item.trackId ?? ""),
        title: asString(item.name) ?? "跑步漫游歌曲",
        subtitle: asArray<AnyRecord>(item.ar)
          .map((artist) => asString(artist.name))
          .filter((artist): artist is string => Boolean(artist))
          .join(" / "),
        coverUrl: asString(asObject(item.al).picUrl),
        trackId: item.id ? String(item.id) : undefined,
        bpm
      })
    );
    return {
      tags: [{ id: "sport", name: `跑步漫游 · ${bpm} BPM` }],
      resources
    };
  }
}

export function createNeteaseLikeAdapterFromEnv() {
  const baseUrl = process.env.MUSIC_SOURCE_BASE_URL ?? "";
  const apiKey = process.env.MUSIC_SOURCE_API_KEY ?? "";

  if (!baseUrl) {
    throw new AppError("Missing MUSIC_SOURCE_BASE_URL", {
      code: 2007,
      status: 500,
      retryable: false
    });
  }

  const envEnabled = (key: string, fallback = false) => {
    const value = process.env[key];
    if (!value) return fallback;
    return ["1", "true", "yes", "on"].includes(value.toLowerCase());
  };

  const unblockSources = parseCsvList(process.env.MUSIC_SOURCE_UNBLOCK_SOURCES);
  const unblockSourceLegacy = process.env.MUSIC_SOURCE_UNBLOCK_SOURCE ?? "";

  return new NeteaseLikeAdapter({
    baseUrl,
    apiKey: apiKey || undefined,
    timeoutMs: Number(process.env.MUSIC_SOURCE_TIMEOUT_MS ?? "6000"),
    retries: Number(process.env.MUSIC_SOURCE_RETRY_TIMES ?? "2"),
    playLevel: process.env.MUSIC_SOURCE_PLAY_LEVEL ?? "standard",
    downloadLevel: process.env.MUSIC_SOURCE_DOWNLOAD_LEVEL ?? "exhigh",
    vipPreviewMaxMs: Number(process.env.MUSIC_SOURCE_VIP_PREVIEW_MAX_MS ?? "60000"),
    lyricPreferNew: envEnabled("MUSIC_SOURCE_LYRIC_PREFER_NEW", true),
    enableDiscover: envEnabled("MUSIC_SOURCE_ENABLE_DISCOVER", true),
    enableScene: envEnabled("MUSIC_SOURCE_ENABLE_SCENE", true),
    pathPlayUrlUnblock: process.env.MUSIC_SOURCE_PATH_PLAY_URL_UNBLOCK ?? "/song/url/match",
    unblockSource: unblockSourceLegacy,
    unblockSources: unblockSources.length ? unblockSources : parseCsvList(unblockSourceLegacy),
    pathSearch: process.env.MUSIC_SOURCE_PATH_SEARCH ?? "/search",
    pathTrackDetail: process.env.MUSIC_SOURCE_PATH_TRACK_DETAIL ?? "/song/detail",
    pathPlayUrl: process.env.MUSIC_SOURCE_PATH_PLAY_URL ?? "/song/url/v1",
    pathLyric: process.env.MUSIC_SOURCE_PATH_LYRIC ?? "/lyric",
    pathLyricNew: process.env.MUSIC_SOURCE_PATH_LYRIC_NEW ?? "/lyric/new",
    pathPlaylist: process.env.MUSIC_SOURCE_PATH_PLAYLIST ?? "/playlist/detail",
    pathSearchHotDetail: process.env.MUSIC_SOURCE_PATH_SEARCH_HOT_DETAIL ?? "/search/hot/detail",
    pathSearchDefault: process.env.MUSIC_SOURCE_PATH_SEARCH_DEFAULT ?? "/search/default",
    pathSearchSuggestPc: process.env.MUSIC_SOURCE_PATH_SEARCH_SUGGEST_PC ?? "/search/suggest/pc",
    pathBanner: process.env.MUSIC_SOURCE_PATH_BANNER ?? "/banner",
    pathPersonalized: process.env.MUSIC_SOURCE_PATH_PERSONALIZED ?? "/personalized",
    pathToplistDetail: process.env.MUSIC_SOURCE_PATH_TOPLIST_DETAIL ?? "/toplist/detail",
    pathTopPlaylistHighquality: process.env.MUSIC_SOURCE_PATH_TOP_PLAYLIST_HIGHQUALITY ?? "/top/playlist/highquality",
    pathToplist: process.env.MUSIC_SOURCE_PATH_TOPLIST ?? "/toplist",
    pathAlbum: process.env.MUSIC_SOURCE_PATH_ALBUM ?? "/album",
    pathAlbumDetail: process.env.MUSIC_SOURCE_PATH_ALBUM_DETAIL ?? "/album/detail",
    pathArtistDetail: process.env.MUSIC_SOURCE_PATH_ARTIST_DETAIL ?? "/artist/detail",
    pathArtistTopSong: process.env.MUSIC_SOURCE_PATH_ARTIST_TOP_SONG ?? "/artist/top/song",
    pathCheckMusic: process.env.MUSIC_SOURCE_PATH_CHECK_MUSIC ?? "/check/music",
    pathSongCreators: process.env.MUSIC_SOURCE_PATH_SONG_CREATORS ?? "/song/creators",
    pathSongWikiSummary: process.env.MUSIC_SOURCE_PATH_SONG_WIKI_SUMMARY ?? "/song/wiki/summary",
    pathSongChorus: process.env.MUSIC_SOURCE_PATH_SONG_CHORUS ?? "/song/chorus",
    pathSongCopyrightRcmd: process.env.MUSIC_SOURCE_PATH_SONG_COPYRIGHT_RCMD ?? "/song/copyright/rcmd",
    pathSongDownloadUrl: process.env.MUSIC_SOURCE_PATH_SONG_DOWNLOAD_URL ?? "/song/download/url/v1",
    pathSatiTagList: process.env.MUSIC_SOURCE_PATH_SATI_TAG_LIST ?? "/sati/tag/list",
    pathSatiResourceList: process.env.MUSIC_SOURCE_PATH_SATI_RESOURCE_LIST ?? "/sati/resource/list",
    pathRadioSportGet: process.env.MUSIC_SOURCE_PATH_RADIO_SPORT_GET ?? "/radio/sport/get"
  });
}
